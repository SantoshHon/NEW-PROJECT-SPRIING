package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.pojo.SlabMaster;

public interface SlabMasterServiceInterface {

	public SlabMaster getSlabMasterBySlabMasterId(int slabMasterId);

	public List<SlabMaster> getAllSlabMaster();
}
