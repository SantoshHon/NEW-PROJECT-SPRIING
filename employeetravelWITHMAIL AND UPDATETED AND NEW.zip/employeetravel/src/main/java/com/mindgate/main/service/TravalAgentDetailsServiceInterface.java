package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.pojo.TravelAgentDetails;

public interface TravalAgentDetailsServiceInterface {

	public TravelAgentDetails getTravalAgentDetailsByAgentId(int agentId);

	public List<TravelAgentDetails> getAllTravalAgentDetails();

}
